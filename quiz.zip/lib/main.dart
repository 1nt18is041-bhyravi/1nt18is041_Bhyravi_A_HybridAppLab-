import 'package:flutter/material.dart';
import 'package:quizapp/Questions.dart';
void main() {
  runApp(MaterialApp(
    home: SafeArea(
      child: Scaffold(
        body: QuizPage(),
      ),
    ),
  ));
}
class QuizPage extends StatefulWidget {
  const QuizPage({Key? key}) : super(key: key);
  @override
  _QuizPageState createState() => _QuizPageState();
}
class _QuizPageState extends State<QuizPage> {
  int questionNumber = 0; // stores the questionNumber, default = first
  int currentScore = 0; // final score initialized to 0
  Questions questions = Questions(); // Create an object of the Question Class

  void updateQuestionNumber() {
    setState(() {
      questionNumber = questionNumber + 1; // Increments the Question Number
      print('$questionNumber');
    });
  }
  void updateCurrentScore(bool choice, int question_number) {
// based on the choice (T/F button) score will be updated
    if (questions.questionBank.length == question_number) {
      print("End of questions");
    } else {
// checks the current user input against the list answer, if true increments the count
      if (questions.questionBank[question_number].answer == choice) {
        setState(() {
          currentScore++;
        });
      }
    }
  }
// function to ensure that the question number to be not crossing the boundary ofthe list
  bool checkquestionNumber(int questionNumber) {
    return questionNumber < questions.questionBank.length ? true : false;
  }
  @override
  Widget build(BuildContext context) {
    return Column(
        children: [
          Center(
            child: Text(checkquestionNumber(questionNumber)?
            questions.questionBank[questionNumber].questionText.toString()
                : " End",
              style: TextStyle(fontSize: 40.0),
            ),
          ),
          SizedBox(height: 20.0),
          ElevatedButton(
            onPressed: () {
              setState(() {
                print('True is pressed');
                if (questionNumber == questions.questionBank.length) { // check the boundof the list
                  print("End of questions");
                } else {
// check the user answer against the answer in the list
                  updateCurrentScore(true, questionNumber);
// increment the Question Number
                  updateQuestionNumber();
                }

              });
            },
            child: Text('True'),
          ),
          SizedBox(width: 20.0),
          ElevatedButton(
            onPressed: () {
              setState(() {
                print('false is pressed');
                if (questionNumber == questions.questionBank.length) { // check the boundof the list
                  print("End of questions");
                } else {
// check the user answer against the answer in the list
                  updateCurrentScore(false, questionNumber);
// increment the Question Number
                  updateQuestionNumber();
                }
              });
            },
            child: Text('False'),
          ),
          SizedBox(
            height: 100.0,
          ),
          SizedBox(
            height: 50.0,
          ),
          Padding(
            padding: const EdgeInsets.all(30.0),
            child: Center(
              child: Text(
                "Current Score is:",
                style: TextStyle(fontSize: 30),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(30.0),
            child: Center(
              child: Text(
                '${currentScore}',
                style: TextStyle(fontSize: 30),
              ),
            ),
          ),
        ]
    ); // Build the Widget Tree here
  }
}
