class Question {
  final String questionText; // Question
  final bool answer; // Answer
  Question({required this.questionText, required this.answer});
// making it as named arguments for the Question Constructor
}