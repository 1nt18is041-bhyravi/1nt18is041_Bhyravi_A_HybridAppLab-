import 'package:flutter/material.dart';
import 'package:audioplayers/src/audio_cache.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title:"xylophone application",
      home: Xylo(),
    );
  }
}

class Xylo extends StatefulWidget {
  const Xylo({Key? key}) : super(key: key);

  @override
  _XyloState createState() => _XyloState();
}

class _XyloState extends State<Xylo> {
  void playAudio(int i){
    final player =AudioCache();
    player.play("note$i.wav");
  }
  Expanded musicTitle(Color color,int noteNumber){
    return  Expanded(child: TextButton(onPressed: () { playAudio(noteNumber); },child: Text(""),style:TextButton.styleFrom(backgroundColor: color)

    ));
  }
  @override
  Widget build(BuildContext context) {
    //var crossAxisAlignment;
    return SafeArea(child: Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children:[
        musicTitle(Colors.red, 1),
        musicTitle(Colors.orange, 2),
        musicTitle(Colors.black, 3),
        musicTitle(Colors.blue, 4),
        musicTitle(Colors.pink, 5),
        musicTitle(Colors.green, 6),
        musicTitle(Colors.purple, 7),


      ]
    ));
  }
}




